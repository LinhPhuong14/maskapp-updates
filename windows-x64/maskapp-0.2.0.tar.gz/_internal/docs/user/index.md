# Hướng dẫn sử dụng

maskapp thay thông tin nhạy cảm trong file Excel/CSV bằng mã như `[NG-0000007-Z]` trước khi bạn
đưa dữ liệu lên AI, rồi khôi phục thông tin thật trong kết quả AI trả về. Mọi thứ chạy trên máy
của bạn; app không gửi dữ liệu đi đâu.

## Che file và gửi cho AI

1. Ở tab **Che file**, bấm **Chọn file…** hoặc kéo file Excel/CSV vào vùng tải file. Hộp mật
   khẩu **Dự án của tôi** vẫn dùng như trước. **Quên mật khẩu thì không khôi phục được tên thật
   từ kết quả AI**.
2. Mỗi tiêu đề cột hiện một dòng, kể cả khi có ở nhiều sheet. Xem **Ví dụ** và **AI sẽ thấy**.
   App che mặc định những chỗ chưa chắc, đánh dấu **Nên xem**. Nếu cần, đổi menu **Cách xử lý**;
   kết quả ví dụ đổi ngay. Tên trong ghi chú được che mặc định. Tên trùng ở khác đơn vị mặc định
   được coi là khác người. Cột có ổ khoá ghi rõ lý do để trống hoặc bỏ theo quy định.
3. Bấm **Sao chép cho AI** rồi dán vào AI, hoặc **Tải file đã che** để đính kèm. Dấu ✓ ngay trên
   trang báo đã xong. Khi nội dung quá dài, dùng file đã che để tránh AI bỏ sót dữ liệu.
4. Giữ **Nhớ cho file cùng mẫu** để lần sau app áp lại các lựa chọn theo bộ tiêu đề, kể cả khi
   đổi tên file hoặc sheet. Mẫu đã nhớ hiện ở màn tải file; xem và xoá trong **Cài đặt**.
5. Khi AI trả lời, mở tab **Khôi phục câu trả lời AI** rồi dán. Tên đã khôi phục được tô màu.
   Với mã sai, kiểm tra câu “có phải…?” và bấm **Đúng, thay vào** cho từng chỗ nếu đúng.
   App không tự sửa mã sai. Bấm **Sao chép kết quả** khi hoàn tất.

Có thể thả nhiều file; xử lý file hiện tại rồi bấm **File tiếp theo**. **Ctrl+V** ở tab Che file
nhận file đã sao chép từ trình quản lý file; ở tab Khôi phục nhận câu trả lời AI. **Ctrl+1** mở
Che file; **Ctrl+2** mở Khôi phục. **F1** mở hướng dẫn; **Ctrl+/** mở bảng phím tắt.

Muốn AI tính toán trên cột bị để trống? Mở **Cài đặt → Xuất cho AI**, chọn **Chỉ gửi tên cột**
để nhờ AI viết công thức, rồi chạy ở tab **Chạy công thức AI viết**. Số liệu thật ở lại máy bạn.

## Chế độ chi tiết – mở trong Cài đặt

1. **Dự án** → *Tạo dự án…* (lần đầu) hoặc *Mở dự án…*. Khi tạo, chọn chính sách:
   - *Tự chọn quy tắc* (mặc định, khi làm một mình): chọn việc được làm với từng mức (xuất sau khi
     thay mã / chỉ gửi tên cột / cấm xuất / cấm nạp), tích các cột luôn coi là nhạy cảm (lương,
     số tài khoản…), bật dò dấu độ mật. Sửa lại sau ở trang chính sách chi tiết (**Ctrl+6**) → *Chỉnh chính sách…*.
   - *File chính sách của trưởng nhóm* (`.maskpolicy`): chính sách bị khoá, chỉ người phát hành
     ký được bản mới.

   Rồi đặt mật khẩu dự án (nên từ 8 ký tự, khó đoán; mật khẩu dễ đoán thì app nhắc một lần). **Mất mật khẩu là mất dữ liệu**: app không
   có cách mở lại.
2. Nhập **Kỳ** (ví dụ `2026-10`, `2026-Q3`, `2026`), chọn mức phân loại, bấm *Chọn file … và nạp*.
   Trước khi nạp, app báo sheet ẩn, comment, liên kết ngoài, hình, biểu đồ, pivot và **dấu độ
   mật** (nếu file có dấu, mức được nâng tự động, bạn không hạ được). Nạp lại cùng tên trong cùng
   kỳ là phiên bản mới, không cộng dồn số liệu.
3. **Xem lại chỗ cần che**: app đề xuất cách xử lý từng cột và rà từng ô văn bản. Dòng **tô vàng**
   là mục bạn phải quyết định:
   - Cột: chọn cột → chọn *Cách xử lý* (thay mã / giữ nguyên / chỉ giữ tháng,
     quý, năm / bỏ cột) → *Áp cho cột đã chọn*.
   - Trong ô: chọn mục → *Che* hoặc *Giữ nguyên*. Trùng tên (một cách gọi ứng với nhiều người):
     chọn đúng mã trong ô *Người nào?*. Quyết định áp cho mọi ô có cùng nội dung.
   - Cùng họ tên ở nhiều đơn vị (bảng cuối trang): chọn *Khác người (hai mã)* nếu là những người
     khác nhau – AI sẽ không gộp họ làm một; *Cùng một người* nếu là cùng một người.
   - *Che tất cả mục còn lại* / *Bỏ qua tất cả mục còn lại*: có hỏi xác nhận và được ghi nhật ký.
   - *Kiểm tra tổ hợp thuộc tính*: chọn vài cột sẽ giữ nguyên (đơn vị, năm sinh…) để biết có dòng
     nào bị nhận ra qua tổ hợp đó không.
   Lần sau, file cùng mẫu chỉ còn phần mới phát sinh cần duyệt.
4. **Xuất cho AI**: chọn file và cách làm việc:
   - *Gửi dữ liệu đã che* – khi cần AI viết nhận xét, tóm tắt, phân loại. Nút xuất chỉ bật khi đã
     duyệt xong. App kiểm tra khôi phục được 100% trên file vừa ghi rồi mới trao file. Bản xuất không
     có metadata, pivot, biểu đồ, hình, comment, liên kết ngoài, sheet ẩn; có sheet `_HUONG_DAN`.
     *Sao chép cho AI* đặt dữ liệu + câu dặn vào bộ nhớ tạm để dán thẳng vào ô chat.
   - *Chỉ gửi tên cột* – khi cần thống kê, pivot, so sánh kỳ: AI chỉ thấy tên cột, kiểu dữ liệu, dòng
     mẫu giả và nhờ viết truy vấn; không giá trị thật nào rời máy.
5. Làm việc với AI bên ngoài app (xem mục dưới).
6. **Khôi phục**:
   - *Văn bản*: dán câu trả lời của AI, app tự khôi phục; bấm *Sao chép kết quả*.
     Mã sai chỉ được sửa từng chỗ sau khi bạn xác nhận.
   - *Bảng CSV/XLSX*: nạp file AI trả về. Mã sai, biến dạng, thiếu, sai loại được liệt kê theo ô
     (`Sheet!B12`); gợi ý mã gần đúng **chỉ áp khi bạn chọn** *Áp gợi ý*. Xuất CSV, XLSX mới, hoặc
     XLSX **từ bản sao file gốc** (giữ pivot, biểu đồ, hình; pivot tự làm mới khi mở).
   - *Chạy công thức AI viết*: dán truy vấn AI viết (từ bản chỉ gửi tên cột) → *Giải thích và
     chạy*. Đọc phần **Cách tính** và **Đối chiếu tổng** trước, rồi mới *Xuất XLSX* hoặc *Báo cáo
     DOCX* (có biểu đồ dựng trên máy, sửa được trong Word).

## Đặt câu dặn trong Project của công cụ AI

Mã chỉ khôi phục được khi AI giữ đúng từng ký tự. Để AI luôn nhớ quy tắc:

1. Trong công cụ AI (ví dụ Claude), tạo một **Project** riêng cho công việc này.
2. Mở phần hướng dẫn của Project (*Project instructions* / *Custom instructions*), dán nguyên văn
   **câu dặn** ở trang *Xuất cho AI* (cũng có ở đầu sheet `_HUONG_DAN` của mọi bản xuất).
3. Mỗi lần gửi dữ liệu, vẫn đính kèm file xuất (có `_HUONG_DAN` liệt kê mã hợp lệ) hoặc dùng *Sao
   chép cho AI* – câu dặn đi kèm.
4. Khi nhờ AI trả bảng: yêu cầu giữ cột mã ở mỗi dòng, không để trống ô mã.
5. Với bản *chỉ gửi tên cột*: nhờ AI viết **một câu truy vấn SQL**; tên sheet và tên cột đặt trong
   ngoặc kép, ví dụ `SELECT "Đơn vị", sum("Lương cơ bản") FROM "Nhân sự 1" GROUP BY 1`.

Không đưa tài liệu có dấu Mật, Tối mật, Tuyệt mật lên AI công cộng dưới bất kỳ hình thức nào.

## Chính sách, nhật ký, sao lưu

- **Cài đặt → Chính sách · chỉ xem** (trang chi tiết: **Ctrl+6**): xem các mức và quy tắc đang áp; gán mức cho dự án; nhận bản chính sách mới (phải
  do đúng người đã phát hành ký). Trưởng nhóm/trưởng phòng: *Tạo khoá ký*, sửa danh mục mức (JSON),
  *Ký và phát hành* file `.maskpolicy`.
- **Cài đặt → Nhật ký**: chỉ xem – ghi mọi lần nạp, xuất, bị chặn, bỏ qua duyệt, khôi phục, xoá, sao lưu. Nút
  *Kiểm tra toàn vẹn* phát hiện nhật ký bị sửa ngoài app.
- **Sao lưu**: trang Dự án → *Sao lưu ngay* (file `.maskbak` đã mã hoá) và đặt lịch (số ngày). Đổi
  máy: cài app → *Mở bản sao lưu…* → chọn thư mục trống → nhập mật khẩu dự án.
- **Tự khoá**: không thao tác 15 phút, app đóng dự án; nhập lại mật khẩu để tiếp tục.
- **Lưu và xoá**: dữ liệu gốc giữ 36 tháng (hoặc ngắn hơn theo mức phân loại); hết hạn app tự xoá
  khi mở dự án và ghi nhật ký. Sổ ghi nhớ mã giữ nguyên để khôi phục kết quả cũ.

## Cài đặt

- **Windows**: chạy `maskapp-<phiên bản>-windows-x64-setup.exe`. Không cần quyền quản trị.
- **macOS**: mở `maskapp-<phiên bản>-macos-arm64.dmg`, kéo maskapp vào Applications.

Kiểm tra file tải về: so SHA-256 với `SHA256SUMS.txt` trong trang phát hành.

## Khi gặp lỗi

Trợ giúp → **Xuất gói chẩn đoán**. App hiện toàn bộ nội dung gói (dữ liệu thật đã được che); bạn
xem rồi mới lưu, và tự quyết định gửi cho người hỗ trợ. App không tự gửi báo lỗi.

## Xem hướng dẫn khi không có mạng

Trợ giúp → **Hướng dẫn sử dụng**. Tài liệu này nằm sẵn trong bộ cài; app không mở trang web nào.

## Cập nhật

Tắt mặc định. App **không có máy chủ cập nhật mặc định**: bộ phận IT của đơn vị đặt bộ file cập
nhật lên máy chủ nội bộ và khai báo địa chỉ trong `org.json`. Khi chưa khai báo, mục Trợ giúp →
Cập nhật bị tắt và ghi rõ "chưa cấu hình máy chủ cập nhật".

Khi đã khai báo và bạn bật trong cài đặt, app chỉ kết nối tới máy chủ đó để kiểm tra bản mới có
chữ ký hợp lệ. Cập nhật không động tới thư mục dự án hay sổ ghi nhớ mã của bạn.

Nếu kiểm tra không thành công, app hiện hộp thoại nói rõ lý do, ví dụ "Dữ liệu cập nhật trên máy
chủ của đơn vị đã quá hạn…" hoặc "Không kết nối được máy chủ cập nhật của đơn vị…". App vẫn dùng
bình thường; hãy báo bộ phận IT của đơn vị.
